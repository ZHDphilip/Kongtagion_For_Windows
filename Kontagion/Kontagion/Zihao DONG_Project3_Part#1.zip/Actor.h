#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
//#include "GameConstants.h"
//#include "StudentWorld.h"
#include <cstdlib>
#include <string>


// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;

class Actor :public GraphObject {
public:
	Actor(StudentWorld* studentWorld,int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0)
		:GraphObject(imageID, startX, startY, dir, depth, size), m_studentWorld(studentWorld),m_alive(true) {}
	virtual void doSomething() = 0;
	StudentWorld* getMyStudentWorld() const { return m_studentWorld; }
	bool isAlive() const { return m_alive; }
	virtual void setDead() { m_alive = false; }
	virtual bool isDamagable() const = 0;
	virtual bool isDirt() const = 0;
	virtual bool isBacteria() const = 0;
	virtual bool isFood() const = 0;
	//virtual int getType() const = 0;
	virtual int getHealth() const { return -1; }
	virtual void takeDamage(int amount) {}
	virtual int Power() const { return 0; }
	virtual void dying() const {}
	virtual void hurting() const {}
	virtual int worth() const { return 0; }
private:
	StudentWorld* m_studentWorld;
	bool m_alive;
};

class Socrates :public Actor {
public:
	Socrates(StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0)
		:Actor(studentWorld, IID_PLAYER, startX, startY, 0, 0, size) {
		m_health = 100;
		m_spray = 20;
		m_flame = 5;
		//m_life = 3;
		m_directionAngle = 180;
	}
	virtual void doSomething();
	int getSpray() const { return m_spray; }
	int getFlame() const { return m_flame; }
	void restoreHealth() { m_health = 100;}
	//void increLife() { m_life++; }
	void increFlame() { m_flame+=5; }
	void takeDamage(int amount) {
		m_health -= amount;
	}
	//virtual int getType() const { return IID_PLAYER; }
	virtual bool isFood() const {
		return false;
	}
	virtual bool isDamagable() const {
		return false;
	}
	virtual bool isDirt() const {
		return false;
	}
	virtual bool isBacteria() const {
		return false;
	}
	int getHealth() const { return m_health; }
	//int getLife() { return m_life; }
private:
	int m_health;
	int m_spray;
	int m_flame;
	//int m_life;
	int m_directionAngle;
};

class Damagable :public Actor {
public:
	Damagable(StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Actor(studentWorld, imageID, startX, startY, dir, depth, size) {}
	virtual void doSomething() = 0;
	virtual bool isFood() const {
		return false;
	}
	virtual bool isDamagable() const {
		return true;
	}
	virtual bool isDirt() const {
		return false;
	}
	virtual bool isBacteria() const {
		return false;
	}
};

class Dirt_Pile :public Damagable {   //remember this should be a damagable object
public:
	Dirt_Pile(StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir = 0, int depth = 1, double size = 1.0)
		:Damagable(studentWorld, IID_DIRT, startX, startY, 0, 1, size) {}
	virtual void doSomething();
	//virtual int getType() const { return IID_DIRT; }
	virtual bool isDirt() const {
		return true;
	}
};
class Projectile :public Actor {
public:
	Projectile(StudentWorld* studentWorld,int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Actor(studentWorld, imageID, startX, startY, dir, depth, size) {
		m_disTraveled = 0;
		m_angle = dir;
	}
	virtual int getMax() const = 0;
	virtual void doSomething() ;
	virtual bool isFood() const {
		return false;
	}
	virtual bool isDamagable() const {
		return false;
	}
	virtual bool isDirt() const {
		return false;
	}
	virtual bool isBacteria() const {
		return false;
	}
private:
	int m_disTraveled;
	int m_angle;
};

class Flame :public Projectile {
public:
	Flame(StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Projectile(studentWorld, IID_FLAME, startX, startY, dir, 1, size) {}
	virtual int getMax() const  { return 32; }
	virtual int Power() const { return 10; }
	//virtual int getType() const { return IID_FLAME; }
private:
	
};

class Spray :public Projectile {
public:
	Spray(StudentWorld* studentWorld,int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Projectile(studentWorld, IID_SPRAY, startX, startY, dir, 1, size) {}
	virtual int getMax() const { return 112; }
	virtual int Power() const { return 2; }
	//virtual int getType() const { return IID_SPRAY; }
private:
	
};

class Goodies :public Damagable {
public:
	Goodies(int lifetime,StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Damagable(studentWorld, imageID, startX, startY, dir, depth, size) {
		m_lifetime = lifetime;
	}
	virtual void doSomething();
	virtual void decLifetime() { m_lifetime--; }
	virtual int getLifetime() const { return m_lifetime; }
	virtual void effect() = 0;
private:
	double m_lifetime;
};

class Restore_Health_Goodie :public Goodies {
public:
	Restore_Health_Goodie(int lifetime,StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Goodies(lifetime,studentWorld, IID_RESTORE_HEALTH_GOODIE, startX, startY, 0, 1, size) {}
	//virtual int getType() const { return IID_RESTORE_HEALTH_GOODIE; }
	virtual void effect();
	virtual int worth() const {
		return 250;
	}
};

class Flame_Thrower_Goodie :public Goodies {
public:
	Flame_Thrower_Goodie(int lifetime,StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Goodies(lifetime,studentWorld, IID_FLAME_THROWER_GOODIE, startX, startY, 0, 1, size) {}
	//virtual int getType() const { return IID_FLAME_THROWER_GOODIE; }
	virtual void effect();
	virtual int worth() const {
		return 300;
	}
};

class Extra_Life_Goodie :public Goodies {
public:
	Extra_Life_Goodie(int lifetime,StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Goodies(lifetime,studentWorld, IID_EXTRA_LIFE_GOODIE, startX, startY, 0, 1, size) {}
	//virtual int getType() const { return IID_EXTRA_LIFE_GOODIE; }
	virtual void effect();
	virtual int worth() const {
		return 500;
	}
};

class Fungus :public Goodies {
public:
	Fungus(int lifetime, StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Goodies(lifetime, studentWorld, IID_FUNGUS, startX, startY, 0, 1, size) {}
	//virtual int getType() const { return IID_FUNGUS; }
	virtual void effect();
	virtual int worth() const {
		return -50;
	}
};

class Food :public Actor {
public:
	Food(StudentWorld* studentWorld, int imageId, double startX, double startY, Direction dir, int depth, double size)
		:Actor(studentWorld, IID_FOOD, startX, startY, 90, 1, 1.0) {}
	//virtual int getType() const{ return IID_FOOD; }
	virtual void doSomething() {}
	virtual bool isFood() const {
		return true;
	}
	virtual bool isDamagable() const {
		return false;
	}
	virtual bool isDirt() const {
		return false;
	}
	virtual bool isBacteria() const {
		return false;
	}
	virtual int Power() const { return 0; }
};

class Pit :public Actor {
public:
	Pit(StudentWorld* studentWorld, int imageId, double startX, double startY, Direction dir, int depth, double size)
		:Actor(studentWorld, IID_PIT, startX, startY, 0, 1, size) {
		m_R = 5;
		m_A = 3;
		m_E = 2;

	}
	virtual int getType() const { return IID_PIT; }
	void emitR() { m_R--; }
	void emitA() { m_A--; }
	void emitE() { m_E--; }
	virtual void doSomething();
	virtual bool isFood() const {
		return false;
	}
	virtual bool isDamagable() const {
		return false;
	}
	virtual bool isDirt() const {
		return false;
	}
	virtual bool isBacteria() const {
		return false;
	}
private:
	int m_R;
	int m_A;
	int m_E;
};

class bacteria :public Damagable {
public:
	bacteria(int health, StudentWorld* studentWorld, int imageID, double startX, double startY, Direction dir, int depth, double size)
		:Damagable(studentWorld, imageID, startX, startY, 90, 0, size) {
		m_health = health;
		m_movePlan = 0;
		m_foodEaten = 0;
	}
	virtual void doSomething() = 0;
	int getHealth() const { return m_health; }
	int getFoodEaten() const { return m_foodEaten; }
	int getMovePlan() const { return m_movePlan; }
	void setFood(int x) { m_foodEaten = x; }
	void takeDamage(int amount) {
		m_health -= amount;
	}
	void setMovePlan(int x) { m_movePlan = x; }
	virtual int getDamage() const = 0;
	virtual bool isFood() const {
		return false;
	}
	virtual bool isDirt() const {
		return false;
	}
	virtual bool isBacteria() const {
		return true;
	}
	virtual void dying() const;
	virtual void hurting() const;
	virtual bool isRegular() const = 0;
	virtual bool isAgressive() const = 0;
	virtual bool isEcoli() const = 0;
	bool moveOrBlock();
	void goToFood();
	void generateNewCoor(bacteria* a, double& xC, double& yC);
	double distToS(bacteria* a);
	void randomDir();
	void pointTowardS();
	virtual int worth() const { return 100; }
private:
	int m_health;
	int m_movePlan;
	int m_foodEaten;
};

class regular :public bacteria {
public:
	regular(int health, StudentWorld* studentWorld, int imageId, double startX, double startY, Direction dir, int depth, double size)
		:bacteria(4, studentWorld, IID_SALMONELLA, startX, startY, 90, 0, 1) {}
	virtual void doSomething();
	//virtual int getType() const { return IID_SALMONELLA; }
	virtual int getDamage() const { return 1; }
	bool isRegular() const { return true; }
	bool isAgressive() const { return false; }
	bool isEcoli() const { return false; }
};

class Agressive :public bacteria {
public:
	Agressive(int health, StudentWorld* studentWorld, int imageId, double startX, double startY, Direction dir, int depth, double size)
		:bacteria(10, studentWorld, IID_SALMONELLA, startX, startY, 90, 0, 1) {}
	virtual void doSomething();
	//virtual int getType() const { return IID_SALMONELLA + 1; }
	virtual int getDamage() const { return 2; }
	bool isRegular() const { return false; }
	bool isAgressive() const { return true; }
	bool isEcoli() const { return false; }
	
};

class Ecoli :public bacteria {
public:
	Ecoli(int health, StudentWorld* studentWorld, int imageId, double startX, double startY, Direction dir, int depth, double size)
		:bacteria(5, studentWorld, IID_ECOLI, startX, startY, 90, 0, 1) {}
	virtual void doSomething() {}
	//virtual int getType() const { return IID_ECOLI; }
	virtual int getDamage() const { return 4; }
	virtual void dying() const;
	virtual void hurting() const;
	bool isRegular() const { return false; }
	bool isAgressive() const { return false; }
	bool isEcoli() const { return true; }
};
#endif // ACTOR_H_
